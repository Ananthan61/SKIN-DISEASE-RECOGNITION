# Skin Disease Recognition
### Convolutional Neural Network trained to classify skin diseases, including skin cancer
----
Files:
- Derm_Image_Scraper_v2: Quick and dirty scraper (but well commented)
- retrain_classify: Inference on pretrained model for image classification

Note: Excludes code defining the CNN architecture and training (fine tuning) the model
